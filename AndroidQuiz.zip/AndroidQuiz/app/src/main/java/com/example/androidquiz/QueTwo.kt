package com.example.androidquiz


import android.os.Bundle
import android.support.v4.app.Fragment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_quiz.*
import kotlinx.android.synthetic.main.fragment_que_one.*
import kotlinx.android.synthetic.main.fragment_quetwo.*


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 *
 */
class Quetwo : Fragment() {

    public var activityContext = activity

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_quetwo, container, false)
    }


    override  fun onStart() {
        super.onStart()

        txtQueTwo.setText(R.string.Question2)
        (activity as QuizActivity).btnNext.setVisibility(View.INVISIBLE)
        (activity as QuizActivity).btnFinishQuiz.setVisibility(View.INVISIBLE)
        (activity as QuizActivity).FragmentTwoScore = 0

        radioGroupFragmentTwo.setOnCheckedChangeListener( { group, checkedId ->
            if (checkedId != -1) {
                (activity as QuizActivity).toggleButtonForFragTwo(checkedId)
                Log.e("Radio button in FragmentTwo ID:", checkedId.toString())
            } else {
                Log.e("FragmentTwo onStart ", checkedId.toString())
            }
        })
    }


}
