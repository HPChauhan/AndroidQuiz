package com.example.androidquiz

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*
import android.content.Context
import android.R.layout
import java.io.File
import android.content.Intent
import android.view.View
import kotlinx.android.synthetic.main.activity_quiz.*


class MainActivity : AppCompatActivity() {
    val PREFS_NAME = "MyPrefsFile"
    val FILE_NAME = "UserDetails"
    var fileContent = String()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        btnSaveUserInfo.setOnClickListener {
//            if(editTxtFirstName.toString() == null || editTxtFamilyName.toString() == null || editTxtNickName.toString() == null || editTxtAge.toString() == null){
//
//                lblFillDetails.setVisibility(View.VISIBLE)
//            } else{
                saveData()

           // }


        }

        Log.d("App is in:", "OnCreate Method")


    }

    override fun onStart() {
        super.onStart()

        restoreData()

    }
    override fun onSaveInstanceState(outState: Bundle?, outPersistentState: PersistableBundle?) {
        super.onSaveInstanceState(outState, outPersistentState)
        Log.e("App is in:", "OnSaveInstanceState Method")
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle?) {
        super.onRestoreInstanceState(savedInstanceState)

    }

    fun goToQuiz() {
        val goToQuizActivity = Intent(this, QuizActivity::class.java)
        startActivity(goToQuizActivity)
    }
    fun saveData() {
        val settings = getPreferences(Context.MODE_PRIVATE)
        val editor = settings.edit()
        editor.putString("setting","localPreference.text.toString()")
        editor.apply()
        val outputFile : File = File(this.filesDir, FILE_NAME)
        fileContent = editTxtFirstName.text.toString() +
                " = " + editTxtFamilyName.text.toString() +
                " = " + editTxtNickName.text.toString() +
                " = " + editTxtAge.text.toString()
        outputFile.writeText(fileContent)
        goToQuiz()
        Log.e("Logs:", "Saved in User File")

    }

    fun restoreData() {
        val inputFile : File = File(this.filesDir, "UserDetails")
        if(inputFile.exists()) {
            var string = inputFile.readText().toString().split(" = ")
            if (string[0].toString() != "") {
                editTxtFirstName.setText(string[0].toString())
            }
            else{
                editTxtFirstName.setHint("")

            }

            if (string[1].toString() != "") {
                editTxtFamilyName.setText(string[1].toString())
            }
            else{
                editTxtFamilyName.setHint("")


            }
            if (string[2].toString() != "") {
                editTxtNickName.setText(string[2].toString())
            }
            else{
                editTxtNickName.setHint("")

            }
            if (string[3].toString() != "") {
                editTxtAge.setText(string[3].toString())
            }
            else{
                editTxtAge.setHint("")
            }
        }
        else{
            editTxtFirstName.setHint("")
            editTxtFamilyName.setHint("")
            editTxtNickName.setHint("")
            editTxtAge.setHint("")
        }

        val inputFileScore : File = File(this.filesDir, "UserScoreDetails")
        if(inputFileScore.exists()) {
            var stringScore = inputFileScore.readText().toString()
            if (stringScore != "") {
                txtScore.setText(stringScore.toString())
            } else {
                txtScore.setText("0")
            }
        }
        else{
            txtScore.setText("0")
        }

    }


}
