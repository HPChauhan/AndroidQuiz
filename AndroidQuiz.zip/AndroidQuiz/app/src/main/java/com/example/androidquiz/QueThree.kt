package com.example.androidquiz

import android.os.Bundle
import android.support.v4.app.Fragment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.activity_quiz.*
import kotlinx.android.synthetic.main.fragment_fragment_three.*
import kotlinx.android.synthetic.main.fragment_que_one.*
import kotlinx.android.synthetic.main.fragment_quetwo.*

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 *
 */
class QueThree : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_fragment_three, container, false)
    }

    override  fun onStart() {
        super.onStart()
        (activity as QuizActivity).btnNext.setVisibility(View.INVISIBLE)
        (activity as QuizActivity).btnFinishQuiz.setVisibility(View.INVISIBLE)
        (activity as QuizActivity).FragmentThreeScore = 0


        txtQueThree.setText(R.string.Question3)
        radioGroupFragmentThree.setOnCheckedChangeListener( { group, checkedId ->
            if (checkedId != -1) {
                (activity as QuizActivity).toggleButtonForFragThree(checkedId)
                Log.e("Radio button in FragmentThree ID:", checkedId.toString())

            } else {
                Log.e("FragmentThree onStart", checkedId.toString())
            }
        })
    }
}
