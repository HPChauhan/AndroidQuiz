package com.example.androidquiz

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import kotlinx.android.synthetic.main.activity_quiz.*
import android.util.Log
import android.view.MenuItem
import android.view.View
import kotlinx.android.synthetic.main.fragment_que_one.*
import kotlinx.android.synthetic.main.fragment_que_one.view.*
import kotlinx.android.synthetic.main.fragment_quetwo.*
import android.widget.Toast
import android.widget.RadioButton
import android.widget.RadioGroup
import kotlinx.android.synthetic.main.activity_main.*
import java.io.File


class QuizActivity : AppCompatActivity(){

    val PREFS_NAME = "MyPrefsFile"
    val FILE_NAME = "UserScoreDetails"
    var fileContent = String()
    var FragmentOneScore = 0
    var FragmentTwoScore = 0
    var FragmentThreeScore = 0
    var FragmentFourScore = 0
    var score = 0

    //transaction Object for each fragment
    val fragmentOneObject= QueOne()



    //Fragment Manager declaration
    val fragmentManager = supportFragmentManager
    val fragmentTransactiontest = fragmentManager.beginTransaction()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)
        fragmentTransactiontest.add(R.id.frameLayout, fragmentOneObject).commit()
        btnFinishQuiz.setVisibility(View.INVISIBLE)
    }

    override fun onStart() {
        super.onStart()

    }

    //For every Fragment new transaction Object is called, once object is commited
    public fun toggleButton(checkedId: Int)
    {
        var fragmentTransactionOne= fragmentManager.beginTransaction()
        btnNext.setVisibility(View.VISIBLE)
        btnNext.setOnClickListener{
            val fragmentTwoObject = Quetwo()
            fragmentTransactionOne.replace(R.id.frameLayout, fragmentTwoObject)
            fragmentTransactionOne.addToBackStack(null)
            fragmentTransactionOne.commit()
            if(checkedId.toString() == "2131165260")
            {
                FragmentOneScore = 1
            }
            Log.e("transaction", "In transaction")
        }
    }
    public fun toggleButtonForFragTwo(checkedId: Int)
    {
        val fragmentTransactionTwo= fragmentManager.beginTransaction()
        btnNext.setVisibility(View.VISIBLE)
        btnNext.setOnClickListener{
            val fragmentThreeObject = QueThree()

            fragmentTransactionTwo.replace(R.id.frameLayout, fragmentThreeObject)
            fragmentTransactionTwo.addToBackStack(null)
            fragmentTransactionTwo.commit()
            if(checkedId.toString() == "2131165266")
            {
                FragmentTwoScore = 1
            }

        }
    }
    public fun toggleButtonForFragThree(checkedId: Int)
    {
        val fragmentTransactionThree= fragmentManager.beginTransaction()
        btnNext.setVisibility(View.VISIBLE)
        btnNext.setOnClickListener{
            val fragmentFourObject = QueFour()

            fragmentTransactionThree.replace(R.id.frameLayout, fragmentFourObject)
            fragmentTransactionThree.addToBackStack(null)
            fragmentTransactionThree.commit()
            if(checkedId.toString() == "2131165267")
            {
                FragmentThreeScore = 1
            }

        }
    }
    public fun finishQuiz(checkedId: Int)
    {
        btnFinishQuiz.setVisibility(View.VISIBLE)

        btnFinishQuiz.setOnClickListener{

            finish()
        }
        if(checkedId.toString() == "2131165273")
        {
            FragmentFourScore = 1
        }
        writeToFile()

        }
    fun writeToFile(){
        val outputFile : File = File(this.filesDir, FILE_NAME)
        score = FragmentOneScore + FragmentTwoScore + FragmentThreeScore + FragmentFourScore
        fileContent = score.toString()


        Log.e("score is ====>", score.toString())
        outputFile.writeText(fileContent)
    }
    }

//1. 2131165261
//2. 2131165267
//3. 2131165268
//4. 2131165274

